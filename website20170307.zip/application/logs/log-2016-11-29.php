<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-29 19:32:20 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:32:20 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:33:40 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:33:40 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:33:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:33:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:33:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:34:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:34:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:35:12 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:12 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:53 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:35:53 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:53 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:56 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:35:56 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:56 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:35:58 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:58 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:35:59 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:35:59 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:03 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:03 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:07 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:07 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:07 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:08 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:08 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:08 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:16 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:16 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:16 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:27 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:27 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:29 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:29 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:29 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:31 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:36:31 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:31 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:45 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:45 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:46 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:46 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:52 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:36:52 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:01 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:01 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:09 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:09 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:20 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:20 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:44 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:44 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:47 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:37:47 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:37:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = '{$url}' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:39:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:39:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:39:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:39:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:39:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:40:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:40:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/models/Page_m.php:56) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 20:41:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:41:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/models/Page_m.php:56) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 20:41:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.mod' at line 1 - Invalid query: "SELECT
  p.page_id,
  p.page_title,
  p.slug,
  m.alias,
  m.module_id,
  m.module_name,
  m.module_path,
  pm.module_data
FROM page p
  LEFT JOIN page_module pm ON (pm.page_id = p.`page_id`)
  INNER JOIN module m ON (pm.`module_id` = m.`module_id`)
WHERE slug = 'home' AND m.active = 1
  ORDER BY pm.order"
ERROR - 2016-11-29 20:41:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/models/Page_m.php:56) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 19:42:06 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:42:06 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:02 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:02 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:19 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:19 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:39 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:43:39 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:45:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:45:04 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:45:04 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:45:05 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:45:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:45:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:45:07 --> Severity: Warning --> file_get_contents(/Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/stored_procedures/page/get_page_content_by_id): failed to open stream: No such file or directory /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/core/MY_Model.php 34
ERROR - 2016-11-29 20:45:07 --> Invalid query: 
ERROR - 2016-11-29 20:45:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Exceptions.php:272) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 20:45:47 --> Severity: Warning --> file_get_contents(/Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/stored_procedures/page/get_page_content_by_id): failed to open stream: No such file or directory /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/core/MY_Model.php 34
ERROR - 2016-11-29 20:45:47 --> Invalid query: 
ERROR - 2016-11-29 20:45:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Exceptions.php:272) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 19:46:11 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:11 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:11 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:13 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:13 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:14 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:14 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:15 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:15 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:15 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:17 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:17 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:17 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:19 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:46:19 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:46:19 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:23 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:23 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:23 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:25 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:25 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:25 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:30 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:32 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:32 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:37 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:38 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:51:39 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:51:39 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:52:32 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:32 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:52:34 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:34 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:52:37 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:37 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:52:38 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:52:38 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:18 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:18 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:18 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:26 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:26 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:29 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:29 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:29 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:31 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:31 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:31 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:44 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:44 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:46 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:46 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:47 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:47 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:47 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:53:49 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:53:49 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:54:06 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:54:06 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:55:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:55:04 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:55:04 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:55:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:55:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:56:43 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:56:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:56:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:57:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:57:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:58:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:58:30 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 19:58:36 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 19:58:36 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:00:13 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:00:13 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:00:54 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:00:54 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:00:54 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:01:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:01:05 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:01:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:01:28 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:02:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:02:27 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:27 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:02:42 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:02:42 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:03:23 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:03:23 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:03:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:03:35 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:04:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:04:10 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 21:04:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"' at line 2 - Invalid query: SELECT * FROM module WHERE module.module_id IN (4,6,3,7,5) ORDER BY FIELD('{$primary_key}',4,6,3,7,5);
"
ERROR - 2016-11-29 20:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:04:22 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:04:22 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 21:04:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"' at line 2 - Invalid query: SELECT * FROM module WHERE module.module_id IN (4,6,3,7,5) ORDER BY FIELD('module_id',4,6,3,7,5);
"
ERROR - 2016-11-29 20:04:43 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:04:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:04:43 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 21:04:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"' at line 2 - Invalid query: SELECT * FROM module WHERE module.module_id IN (4,6,3,7,5) ORDER BY FIELD('module_id',4,6,3,7,5);
"
ERROR - 2016-11-29 21:04:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/models/Module_m.php:52) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 20:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:05:03 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:05:03 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 21:05:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"' at line 2 - Invalid query: SELECT * FROM module WHERE module.module_id IN (4,6,3,7,5) ORDER BY FIELD('module_id',4,6,3,7,5);
"
ERROR - 2016-11-29 21:05:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/application/models/Module_m.php:53) /Volumes/Mercury/Development/git-projects/puretours.co.za/dist/system/core/Common.php 573
ERROR - 2016-11-29 20:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:05:21 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:05:21 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2016-11-29 20:05:33 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:05:33 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:16:38 --> 404 Page Not Found: Assets/libs
ERROR - 2016-11-29 20:16:38 --> 404 Page Not Found: Assets/libs
