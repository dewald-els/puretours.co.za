<?php
/**
 * Created by PhpStorm.
 * User: forest-sumo
 * Date: 2016/11/08
 * Time: 1:41 PM
 */
interface IModule
{
    public function get_data_structure();
    public function set_data($data);
}