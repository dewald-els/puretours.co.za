<div class="page" ng-controller="DashboardCtrl">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                       <span class="panel-title"><i class="fa fa-bell"></i> Activity</span>
                    </div>
                    <div class="panel-body">
                        <ul class="panel-title">
                            <li>01-11-2016 19:15 - dewald updated user admin</li>
                            <li>01-11-2016 19:15 - dewald added new post</li>
                            <li>01-11-2016 19:15 - dewald changed featured image</li>
                            <li>01-11-2016 19:15 - dewald logged in</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-xs-8">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <span class="panel-title"><i class="fa fa-newspaper-o"></i> Notices</span>
                    </div>
                    <div class="panel-body">
                        <ul class="panel-title">
                            <li>Remember promotions for December</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>