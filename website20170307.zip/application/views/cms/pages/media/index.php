<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1 class="text-primary text-bold">Media library</h1>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">

                <?php $this->load->view('modules/file-browser/index'); ?>

            </div>
        </div>
    </div>
</div>