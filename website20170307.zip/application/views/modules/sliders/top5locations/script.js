$(document).ready(function () {

    $('.slider').unslider({
        autoplay: true,
        delay: 3000,
        speed: 1000,
        arrows: false
    });

});