<div id="mod-banner-lg" class="banner" style="background: url(<?php echo base_url($this->resources->data['page']->modules['bannerLarge']->data->src); ?>)">

</div>