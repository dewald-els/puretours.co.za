<div id="mod-banner-med" class="banner"
     style="background: url(<?php echo base_url($this->resources->data['page']->modules['bannerMedium']->data->src); ?>)">
</div>