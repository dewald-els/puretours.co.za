<div id="find-your-escape" class="container">
    <div class="row">
        <div class="col-xs-12 text-center">
            <div class="find-your-escape">

                <div class="left-text">
                    <span>Find your</span>
                    <span><b>Escape Now</b></span>
                </div>

                <div>
                    <button class="pt-btn-white btn-select-dest">Select your <b>destination</b> <i
                            class="fa fa-angle-right"></i></button>
                    <button class="pt-btn-white btn-select-dates">Select your <b>dates</b> <i
                            class="fa fa-angle-right"></i></button>
                    <button class="pt-btn">Find your escape</button>
                </div>

            </div>
        </div>
    </div>
</div>