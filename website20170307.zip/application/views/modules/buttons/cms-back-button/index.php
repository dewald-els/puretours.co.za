<a role="button" onclick="window.history.back();" class="btn btn-sm btn-default">
    <i class="fa fa-angle-left"></i> Back
</a>