<div class="mod-package-card">

    <div class="package-card">

        <h4>2017 Hong Kong 7's</h4>


        <div class="left">
            <div class="package-img">
                <img src="<?php echo base_url('assets/img/backgrounds/modules/package-builder/demo-thumb.jpg'); ?>" alt="" width="200">
                <button class="pt-btn">View package <i class="fa fa-angle-right"></i></button>
            </div>
        </div>
        <div class="right">

            <div class="package-content">
                <p>
                    Experience the world's premier event of its kind & one of the most popular sporting events in
                    Asia!

                </p>

                <b>Valid:</b> 25 Mar - 1 Apr 2017 <br>
                <b>Duration:</b> 7 Nights

            </div>

            <div class="package-pricing">

                <h5 class="from">From only</h5><!-->
                <h2 class="price">R32 490</h2>
                <small class="foot-note">per person sharing including taxes</small>

            </div>

        </div>

        <div class="clearfix"></div>


    </div>


</div>