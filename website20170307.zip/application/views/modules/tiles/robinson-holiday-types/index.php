<div class="mod-robinson-holiday-types">

    <div class="container">

        <div class="row">

            <div class="col-xs-6 col-md-3">
                <div class="tile family">
                    <img src="<?php echo base_url('assets/img/backgrounds/modules/robinson/holiday-types/family.png'); ?>" alt="">
                </div>
            </div>

            <div class="col-xs-6 col-md-3">
                <div class="tile feel-good">
                    <img src="<?php echo base_url('assets/img/backgrounds/modules/robinson/holiday-types/feel-good.png'); ?>" alt="">
                </div>
            </div>

            <div class="col-xs-6 col-md-3">
                <div class="tile sport">
                    <img src="<?php echo base_url('assets/img/backgrounds/modules/robinson/holiday-types/sport.png'); ?>" alt="">
                </div>
            </div>

            <div class="col-xs-6 col-md-3">
                <div class="tile winter">
                    <img src="<?php echo base_url('assets/img/backgrounds/modules/robinson/holiday-types/winter.png'); ?>" alt="">
                </div>
                <div class="tile summer">
                    <img src="<?php echo base_url('assets/img/backgrounds/modules/robinson/holiday-types/summer.png'); ?>" alt="">
                </div>
            </div>

        </div>

    </div>

</div>