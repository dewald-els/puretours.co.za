'use strict';

/**
 * Created by dewaldels on 2016/07/09.
 */
/**
 * Created by dewaldels on 2016/07/09.
 */
APP.controller('AppCtrl', ['$scope', '$location', function ($scope, $location) {

    $scope.App = {
        UI: {
            Navbar: {}
        }
    };
    $scope.App.UI.Navbar.getActiveNav = function (url) {

        var _url = $location.absUrl().split('/');
        return _url.indexOf(url) !== -1;
    };

    $scope.App.UI.Navbar.isOpen = '';
    $scope.App.UI.Navbar.toggle = function () {
        $scope.App.UI.Navbar.isOpen = $scope.App.UI.Navbar.isOpen == true ? false : true;
    };
}]);
/**
 * Created by dewaldels on 2016/07/09.
 */
APP.controller('PageCtrl', ['$scope', function ($scope) {
    console.log('Page controller');
}]);
/**
 * Created by forest-sumo on 2017/03/06.
 */

APP.controller('AboutCtrl', ['$scope', function ($scope) {

    $scope.About = {
        activeTab: 'whoWeAre'
    };

    $scope.About.toggleActiveTab = function (newTab) {
        $scope.About.activeTab = newTab;
    };
}]);