'use strict';

/**
 * Created by dewaldels on 2016/07/09.
 */
var APP = angular.module('pureTours', []);
/**
 * Created by dewaldels on 2016/07/09.
 */