'use strict';

/**
 * Created by dewaldels on 2016/07/09.
 */
/**
 * Created by dewaldels on 2016/07/09.
 */
APP.controller('AppCtrl', ['$scope', '$location', function ($scope, $location) {

    $scope.App = {
        UI: {
            Navbar: {}
        }
    };
    $scope.App.UI.Navbar.getActiveNav = function (url) {

        var _url = $location.absUrl().split('/');
        return _url.indexOf(url) !== -1;
    };

    $scope.App.UI.Navbar.isOpen = '';
    $scope.App.UI.Navbar.toggle = function () {
        $scope.App.UI.Navbar.isOpen = $scope.App.UI.Navbar.isOpen == true ? false : true;
    };
}]);
/**
 * Created by forest on 2016/10/26.
 */
APP.controller('DashboardCtrl', ['$scope', function ($scope) {
    console.log('Dashboard controller');
}]);
/**
 * Created by forest on 2016/10/26.
 */
APP.controller('UsersCtrl', ['$scope', '$http', function ($scope, $http) {

    $scope.User = {
        users: [],
        getUsers: function getUsers() {
            $http.get('/admin/users/get_users').then(function (resp) {
                $scope.User.users = resp.data.data;
            }).catch(function (resp) {});
        }
    };

    $scope.User.getUsers();
}]);
/**
 * Created by forest on 2016/10/26.
 */
APP.controller('PagesCtrl', ['$scope', '$http', function ($scope, $http) {

    $scope.Pages = {
        pages: [],
        getPages: function getPages() {
            $http.get('/admin/pages/get_pages').then(function (resp) {
                $scope.Pages.pages = resp.data.data;
            }).catch(function (resp) {});
        }
    };

    $scope.Pages.getPages();
}]);
/**
 * Created by forest on 2016/10/26.
 */
APP.controller('EditPageCtrl', ['$scope', '$http', '$location', function ($scope, $http, $location) {

    var url = $location.absUrl().split('/');

    $scope.EditPage = {
        page_id: url[url.length - 1],
        loadingModules: true,
        modules: [],
        getPageModules: function getPageModules() {
            $http.post('/admin/pages/get-page-modules', {
                page_id: $scope.EditPage.page_id
            }).then(function (resp) {
                $scope.EditPage.loadingModules = false;
                $scope.EditPage.modules = resp.data.data;
            }).catch(function (resp) {
                $scope.EditPage.loadingModules = false;
            });
        }
    };

    $scope.EditPage.getPageModules();
}]);